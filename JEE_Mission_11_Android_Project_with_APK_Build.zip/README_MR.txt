JEE MISSION 11 - Android Studio project

या ZIP मध्ये Android app चा source code आहे. इथे APK compile करण्यासाठी Android SDK/Gradle उपलब्ध नसल्यामुळे APK थेट बनलेली नाही.

APK तयार करण्याचा सर्वात सोपा cloud-build मार्ग:
1. GitHub account मध्ये नवीन private repository तयार कर.
2. ZIP extract करून त्यातील सर्व files/folders repository मध्ये upload कर (including .github folder).
3. Repository च्या Actions tab मध्ये "Build JEE Mission 11 APK" workflow निवड.
4. "Run workflow" दाब.
5. Build पूर्ण झाल्यावर run मधील Artifacts विभागातून "JEE-Mission-11-APK" डाउनलोड कर.
6. ZIP artifact extract केल्यावर app-debug.apk मिळेल. Android वर उघडून install कर.

किंवा संगणकावर Android Studio वापरून Build > Build APK(s) निवडता येईल.

टीप: GitHub वर code upload केल्याशिवाय मी तुझ्या खात्यातून cloud build सुरू करू शकत नाही. Password/OTP कुणालाही देऊ नकोस.
